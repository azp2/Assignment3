package com.springboot.devicemanagement.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;

@Configuration
public class MyAppConfig {
	@Bean
	@Lazy
	public String customSystemMessage() {
		System.out.println(">> Lazy Bean 'customSystemMessage' has been initialized!");
		return "Welcome to Ejada Device Management System!";
	}
}
