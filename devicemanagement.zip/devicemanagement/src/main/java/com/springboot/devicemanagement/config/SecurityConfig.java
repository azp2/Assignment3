package com.springboot.devicemanagement.config;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.JdbcUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

	@Bean
	public JdbcUserDetailsManager userDetailsManager(DataSource dataSource) {
		return new JdbcUserDetailsManager(dataSource);
	}

	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
		http.csrf(csrf -> csrf.disable()).authorizeHttpRequests(auth -> auth
				.requestMatchers("/swagger-ui/**", "/v3/api-docs/**").permitAll()
				.requestMatchers(HttpMethod.GET, "/api/devices/**").hasAnyRole("EMPLOYEE", "MANAGER", "ADMIN")
				.requestMatchers(HttpMethod.POST, "/api/devices/**").hasAnyRole("MANAGER", "ADMIN")
				.requestMatchers(HttpMethod.PUT, "/api/devices/**").hasAnyRole("MANAGER", "ADMIN")
				.requestMatchers(HttpMethod.PATCH, "/api/devices/**").hasAnyRole("MANAGER", "ADMIN")
				.requestMatchers(HttpMethod.DELETE, "/api/devices/**").hasAnyRole("ADMIN")
				.anyRequest().authenticated()).formLogin(Customizer.withDefaults())
				.httpBasic(Customizer.withDefaults());

		return http.build();
	}
}