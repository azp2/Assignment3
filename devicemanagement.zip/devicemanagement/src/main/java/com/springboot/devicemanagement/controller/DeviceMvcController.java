package com.springboot.devicemanagement.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.springboot.devicemanagement.entity.Device;
import com.springboot.devicemanagement.service.DeviceService;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/ui/devices")
public class DeviceMvcController {

	private final DeviceService deviceService;

	public DeviceMvcController(DeviceService deviceService) {
		this.deviceService = deviceService;
	}

	@GetMapping("/list")
	public String listDevices(Model model) {
		model.addAttribute("devices", deviceService.findAll());
		model.addAttribute("newDevice", new Device());
		return "devices-page";
	}

	@PostMapping("/save")
	public String saveDevice(@Valid @ModelAttribute("newDevice") Device theDevice, BindingResult bindingResult,
			Model model) {

		if (bindingResult.hasErrors()) {
			model.addAttribute("devices", deviceService.findAll());
			return "devices-page";
		}

		deviceService.save(theDevice);
		return "redirect:/ui/devices/list";
	}
}