package com.springboot.devicemanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.devicemanagement.entity.Device;
import com.springboot.devicemanagement.service.DeviceService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/devices")
public class DeviceRestController {

	private final DeviceService deviceService;

	@Autowired
	public DeviceRestController(DeviceService deviceService) {
		this.deviceService = deviceService;
	}

	@GetMapping
	public ResponseEntity<List<Device>> getAllDevices(@RequestParam(defaultValue = "id") String sort,
			@RequestParam(defaultValue = "asc") String dir) {

		Sort.Direction direction = dir.equalsIgnoreCase("asc") ? Sort.Direction.ASC : Sort.Direction.DESC;
		List<Device> devices = deviceService.findAll(Sort.by(direction, sort));
		return ResponseEntity.ok(devices);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Device> getDeviceById(@PathVariable Long id) {
		return ResponseEntity.ok(deviceService.findById(id));
	}

	@GetMapping("/category/{category}")
	public ResponseEntity<List<Device>> getDevicesByCategory(@PathVariable String category) {
		return ResponseEntity.ok(deviceService.findByCategory(category));
	}

	@PostMapping
	public ResponseEntity<Device> createDevice(@Valid @RequestBody Device device) {
		device.setId(0L);
		Device savedDevice = deviceService.save(device);
		return new ResponseEntity<>(savedDevice, HttpStatus.CREATED);
	}

	@PutMapping("/{id}")
	public ResponseEntity<Device> updateDevice(@PathVariable Long id, @Valid @RequestBody Device deviceDetails) {
		Device existingDevice = deviceService.findById(id);

		existingDevice.setName(deviceDetails.getName());
		existingDevice.setCategory(deviceDetails.getCategory());
		existingDevice.setPrice(deviceDetails.getPrice());
		existingDevice.setQuantity(deviceDetails.getQuantity());
		existingDevice.setStatus(deviceDetails.getStatus());
		existingDevice.setActive(deviceDetails.isActive());
		existingDevice.setCode(deviceDetails.getCode());

		return ResponseEntity.ok(deviceService.save(existingDevice));
	}

	@PatchMapping("/{id}")
	public ResponseEntity<Device> patchDevice(@PathVariable Long id, @RequestBody Device updates) {
		Device existingDevice = deviceService.findById(id);

		if (updates.getName() != null) {
			existingDevice.setName(updates.getName());
		}
		if (updates.getCategory() != null) {
			existingDevice.setCategory(updates.getCategory());
		}
		if (updates.getPrice() > 0) {
			existingDevice.setPrice(updates.getPrice());
		}
		if (updates.getCode() != null) {
			existingDevice.setCode(updates.getCode());
		}
		if (updates.getStatus() != null) {
			existingDevice.setStatus(updates.getStatus());
		}

		return ResponseEntity.ok(deviceService.save(existingDevice));
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteDevice(@PathVariable Long id) {
		deviceService.findById(id); // بس نتأكد إنه موجود قبل الحذف
		deviceService.deleteById(id);
		return ResponseEntity.ok("Deleted device id: " + id);
	}
}