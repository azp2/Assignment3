package com.springboot.devicemanagement.exception;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler
	public ResponseEntity<Map<String, Object>> handleException(ResourceNotFoundException exc) {
		Map<String, Object> error = new LinkedHashMap<>();
		error.put("status", HttpStatus.NOT_FOUND.value());
		error.put("message", exc.getMessage());

		return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
	}
}