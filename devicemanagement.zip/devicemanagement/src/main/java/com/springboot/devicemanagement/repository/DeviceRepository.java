package com.springboot.devicemanagement.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.devicemanagement.entity.Device;

public interface DeviceRepository extends JpaRepository<Device, Long> {
	List<Device> findByCategory(String category);
}
