package com.springboot.devicemanagement.service;

import java.util.List;

import org.springframework.data.domain.Sort;

import com.springboot.devicemanagement.entity.Device;

public interface DeviceService {
	List<Device> findAll();

	List<Device> findAll(Sort sort);

	Device findById(Long id);

	Device save(Device device);

	void deleteById(Long id);

	List<Device> findByCategory(String category);
}