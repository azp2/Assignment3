package com.springboot.devicemanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.springboot.devicemanagement.entity.Device;
import com.springboot.devicemanagement.exception.ResourceNotFoundException;
import com.springboot.devicemanagement.repository.DeviceRepository;

@Service
public class DeviceServiceImpl implements DeviceService {

	private final DeviceRepository deviceRepository;
	private final NotificationService notificationService;

	@Autowired
	public DeviceServiceImpl(DeviceRepository deviceRepository,
			@Qualifier("emailNotificationService") NotificationService notificationService) {
		this.deviceRepository = deviceRepository;
		this.notificationService = notificationService;
	}

	@Override
	public List<Device> findAll() {
		return deviceRepository.findAll();
	}

	@Override
	public List<Device> findAll(Sort sort) {
		return deviceRepository.findAll(sort);
	}

	@Override
	public Device findById(Long id) {
		return deviceRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Device not found with id: " + id));
	}

	@Override
	public Device save(Device device) {
		Device savedDevice = deviceRepository.save(device);
		notificationService.sendNotification("Device " + savedDevice.getName() + " saved successfully!");
		return savedDevice;
	}

	@Override
	public void deleteById(Long id) {
		deviceRepository.deleteById(id);
	}

	@Override
	public List<Device> findByCategory(String category) {
		return deviceRepository.findByCategory(category);
	}
}