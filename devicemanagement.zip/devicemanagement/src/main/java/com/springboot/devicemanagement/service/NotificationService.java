package com.springboot.devicemanagement.service;

public interface NotificationService {
	void sendNotification(String message);
}
