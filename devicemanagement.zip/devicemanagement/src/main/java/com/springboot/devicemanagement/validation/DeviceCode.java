package com.springboot.devicemanagement.validation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;

@Constraint(validatedBy = DeviceCodeConstraintValidator.class)
@Target({ ElementType.FIELD, ElementType.METHOD })
@Retention(RetentionPolicy.RUNTIME)
public @interface DeviceCode {
	public String value() default "DEV";
	public String message() default "must start with DEV";
	public Class<?>[] groups() default {};
	public Class<? extends Payload>[] payload() default {};
}
