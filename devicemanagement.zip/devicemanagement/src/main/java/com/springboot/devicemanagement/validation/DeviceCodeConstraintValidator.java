package com.springboot.devicemanagement.validation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class DeviceCodeConstraintValidator implements ConstraintValidator<DeviceCode, String> {

	private String expectedPrefix;

	@Override
	public void initialize(DeviceCode theDeviceCode) {
		expectedPrefix = theDeviceCode.value();
	}

	@Override
	public boolean isValid(String theCode, ConstraintValidatorContext theConstraintValidatorContext) {
		if (theCode != null) {
			return theCode.startsWith(expectedPrefix);
		}
		return true;
	}
}